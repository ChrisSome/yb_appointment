<?php

namespace center\modules\appointment;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'center\modules\appointment\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
